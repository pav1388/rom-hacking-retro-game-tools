"""Tiny MIPS32 assembler (subset) and integer emulator (subset) for patch verification."""
import struct

REG = {n: i for i, n in enumerate(['zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7',
                                   's0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra'])}

class Asm:
    def __init__(self, base):
        self.base = base; self.words = []; self.labels = {}; self.fix = []
    @property
    def pc(self): return self.base + 4*len(self.words)
    def label(self, n):
        assert n not in self.labels, n
        self.labels[n] = self.pc
    def emit(self, w): self.words.append(w & 0xffffffff)
    def r(self, s):
        return REG[s]
    def _i(self, op, rs, rt, imm):
        self.emit((op<<26)|(self.r(rs)<<21)|(self.r(rt)<<16)|(imm & 0xffff))
    def _r(self, fn, rd, rs, rt, sa=0):
        self.emit((self.r(rs)<<21)|(self.r(rt)<<16)|(self.r(rd)<<11)|(sa<<6)|fn)
    def nop(self): self.emit(0)
    def addiu(self, rt, rs, imm): self._i(9, rs, rt, imm)
    def li(self, rt, imm):  # 16-bit signed/unsigned small
        if imm < 0: self._i(9, 'zero', rt, imm)
        else: self._i(13, 'zero', rt, imm)
    def move(self, rd, rs): self._r(37, rd, rs, 'zero')
    def andi(self, rt, rs, imm): self._i(12, rs, rt, imm)
    def ori(self, rt, rs, imm): self._i(13, rs, rt, imm)
    def sltiu(self, rt, rs, imm): self._i(11, rs, rt, imm)
    def slti(self, rt, rs, imm): self._i(10, rs, rt, imm)
    def addu(self, rd, rs, rt): self._r(33, rd, rs, rt)
    def subu(self, rd, rs, rt): self._r(35, rd, rs, rt)
    def sltu(self, rd, rs, rt): self._r(43, rd, rs, rt)
    def lbu(self, rt, off, rs): self._i(36, rs, rt, off)
    def lb(self, rt, off, rs): self._i(32, rs, rt, off)
    def lw(self, rt, off, rs): self._i(35, rs, rt, off)
    def sb(self, rt, off, rs): self._i(40, rs, rt, off)
    def jr(self, rs): self._r(8, 'zero', rs, 'zero')
    def _br(self, op, rs, rt, target):
        self.fix.append((len(self.words), target, 'br')); self._i(op, rs, rt, 0)
    def beq(self, rs, rt, t): self._br(4, rs, rt, t)
    def bne(self, rs, rt, t): self._br(5, rs, rt, t)
    def b(self, t): self._br(4, 'zero', 'zero', t)
    def finish(self):
        for idx, tgt, kind in self.fix:
            pc = self.base + 4*idx
            dst = self.labels[tgt] if isinstance(tgt, str) else tgt
            off = (dst - (pc + 4)) >> 2
            assert -32768 <= off < 32768
            self.words[idx] = (self.words[idx] & 0xffff0000) | (off & 0xffff)
        return b''.join(struct.pack('<I', w) for w in self.words)

def bal_word(pc, dst):
    off = (dst - (pc + 4)) >> 2
    assert -32768 <= off < 32768
    return (1 << 26) | (0 << 21) | (17 << 16) | (off & 0xffff)   # bal = bgezal zero

def sx16(v): return v - 0x10000 if v & 0x8000 else v
def s32(v): return v - (1 << 32) if v & 0x80000000 else v

class Emu:
    def __init__(self, mem, size=0x20000):
        self.mem = bytearray(size); self.mem[:len(mem)] = mem
        self.r = [0]*32; self.hi = 0; self.lo = 0; self.pc = 0
        self.steps = 0
    def rd(self, a, n, signed=False):
        v = int.from_bytes(self.mem[a:a+n], 'little')
        if signed and v >= 1 << (8*n-1): v -= 1 << (8*n)
        return v & 0xffffffff if signed else v
    def wr(self, a, n, v): self.mem[a:a+n] = (v & ((1 << (8*n)) - 1)).to_bytes(n, 'little')
    def step_one(self, stop):
        """Execute instruction at pc handling delay slot; returns True if reached stop."""
        pc = self.pc
        nxt = pc + 4
        w = self.rd(pc, 4)
        br = self.exec(w, pc)
        if br is not None:   # branch: execute delay slot then jump
            if br == 'likely_skip':
                self.pc = pc + 8; return
            self.exec_slot(pc + 4)
            self.pc = br
        else:
            self.pc = nxt
    def exec_slot(self, pc):
        w = self.rd(pc, 4)
        br = self.exec(w, pc)
        assert br is None, 'branch in delay slot'
    def run(self, start, stops, maxsteps=200000):
        self.pc = start
        while self.pc not in stops:
            self.step_one(stops); self.steps += 1
            if self.steps > maxsteps: raise RuntimeError('too many steps')
        return self.pc
    def exec(self, w, pc):
        r = self.r; op = w >> 26
        rs = (w >> 21) & 31; rt = (w >> 16) & 31; rd = (w >> 11) & 31; sa = (w >> 6) & 31; fn = w & 63
        imm = w & 0xffff; simm = sx16(imm)
        M = 0xffffffff
        def setr(i, v):
            if i: r[i] = v & M
        if w == 0: return None
        if op == 0:
            if fn == 0: setr(rd, r[rt] << sa)
            elif fn == 2: setr(rd, r[rt] >> sa)
            elif fn == 3: setr(rd, s32(r[rt]) >> sa)
            elif fn == 4: setr(rd, r[rt] << (r[rs] & 31))
            elif fn == 6: setr(rd, r[rt] >> (r[rs] & 31))
            elif fn == 8: return r[rs]
            elif fn == 9: t = r[rs]; setr(rd, pc + 8); return t
            elif fn == 10:
                if r[rt] == 0: setr(rd, r[rs])
            elif fn == 11:
                if r[rt] != 0: setr(rd, r[rs])
            elif fn == 18: setr(rd, self.lo)
            elif fn == 16: setr(rd, self.hi)
            elif fn == 24:
                p = s32(r[rs]) * s32(r[rt]); self.lo = p & M; self.hi = (p >> 32) & M
            elif fn == 25:
                p = r[rs] * r[rt]; self.lo = p & M; self.hi = (p >> 32) & M
            elif fn == 26:
                a, b = s32(r[rs]), s32(r[rt])
                if b: q = int(a / b); self.lo = q & M; self.hi = (a - q*b) & M
            elif fn == 27:
                if r[rt]: self.lo = r[rs] // r[rt]; self.hi = r[rs] % r[rt]
            elif fn == 33 or fn == 32: setr(rd, r[rs] + r[rt])
            elif fn == 35 or fn == 34: setr(rd, r[rs] - r[rt])
            elif fn == 36: setr(rd, r[rs] & r[rt])
            elif fn == 37: setr(rd, r[rs] | r[rt])
            elif fn == 38: setr(rd, r[rs] ^ r[rt])
            elif fn == 39: setr(rd, ~(r[rs] | r[rt]))
            elif fn == 42: setr(rd, int(s32(r[rs]) < s32(r[rt])))
            elif fn == 43: setr(rd, int(r[rs] < r[rt]))
            elif fn == 13 or fn == 52: pass   # break/teq
            else: raise NotImplementedError(f'special fn {fn} at {pc:x}')
            return None
        if op == 31:
            if fn == 0x20 and sa == 0x10: setr(rd, sx16(r[rt] & 0xff) if False else ((r[rt] & 0xff) - 256 if r[rt] & 0x80 else r[rt] & 0xff)); return None
            if fn == 0: setr(rt, (r[rs] >> sa) & ((1 << (rd+1)) - 1)); return None
            raise NotImplementedError(f'op31 {w:08x}')
        if op == 1:
            tgt = pc + 4 + (simm << 2)
            v = s32(r[rs])
            if rt in (0, 2): c = v < 0
            elif rt in (1, 3): c = v >= 0
            elif rt == 17: setr(31, pc + 8); return tgt    # bal
            else: raise NotImplementedError
            if c: return tgt
            return 'likely_skip' if rt in (2, 3) else None
        if op == 2: return ((pc + 4) & 0xf0000000) | ((w & 0x3ffffff) << 2)
        if op == 3: setr(31, pc + 8); return ((pc + 4) & 0xf0000000) | ((w & 0x3ffffff) << 2)
        tgt = pc + 4 + (simm << 2)
        if op in (4, 20):
            if r[rs] == r[rt]: return tgt
            return 'likely_skip' if op == 20 else None
        if op in (5, 21):
            if r[rs] != r[rt]: return tgt
            return 'likely_skip' if op == 21 else None
        if op in (6, 22):
            if s32(r[rs]) <= 0: return tgt
            return 'likely_skip' if op == 22 else None
        if op in (7, 23):
            if s32(r[rs]) > 0: return tgt
            return 'likely_skip' if op == 23 else None
        if op in (8, 9): setr(rt, r[rs] + simm)
        elif op == 10: setr(rt, int(s32(r[rs]) < simm))
        elif op == 11: setr(rt, int(r[rs] < (simm & M)))
        elif op == 12: setr(rt, r[rs] & imm)
        elif op == 13: setr(rt, r[rs] | imm)
        elif op == 14: setr(rt, r[rs] ^ imm)
        elif op == 15: setr(rt, imm << 16)
        elif op == 32: setr(rt, self.rd((r[rs]+simm) & M, 1, True))
        elif op == 33: setr(rt, self.rd((r[rs]+simm) & M, 2, True))
        elif op == 35: setr(rt, self.rd((r[rs]+simm) & M, 4))
        elif op == 36: setr(rt, self.rd((r[rs]+simm) & M, 1))
        elif op == 37: setr(rt, self.rd((r[rs]+simm) & M, 2))
        elif op == 40: self.wr((r[rs]+simm) & M, 1, r[rt])
        elif op == 41: self.wr((r[rs]+simm) & M, 2, r[rt])
        elif op == 43: self.wr((r[rs]+simm) & M, 4, r[rt])
        else: raise NotImplementedError(f'op {op} at {pc:x} word {w:08x}')
        return None
