import sys,struct
from PIL import Image
d=open(sys.argv[1],'rb').read()
n=struct.unpack_from('<I',d,0x34+16)[0]
seg=d[0x60:0x60+n]
# find new table address from patched instruction at 0xc4c
T=struct.unpack_from('<I',seg,0xc4c)[0]&0xffff
B=0x2bdc
def glyph(c):
    o,=struct.unpack_from('<H',seg,T+((c-0x20)&0xff)*2)
    h,w,yb,xo=struct.unpack_from('<BBbb',seg,B+o); rb=(w+1)//2
    return h,w,yb,xo,[[ (seg[B+o+4+r*rb+k//2]>>(4 if k%2==0 else 0))&15 for k in range(w)] for r in range(h)]
lines=[ "2026 Понедельник 11/16 12:27:00 PM 100%(5:30)".encode('cp1251'),
 "Январь Февраль Март Апрель Май Июнь".encode('cp1251'),
 "Июль Август Сентябрь Октябрь Ноябрь Декабрь".encode('cp1251'),
 "Вторник Среда Четверг Пятница Суббота Воскресенье".encode('cp1251'),
 "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ".encode('cp1251'),
 "абвгдеёжзийклмнопрстуфхцчшщъыьэюя".encode('cp1251'),
 "ЄІЇҐ єіїґ ЎЎ № Hello World abc 0123456789".replace('Ў','Ў').encode('cp1251'),
]
W,H=8*52+8,len(lines)*16+8
im=Image.new('RGB',(W,H),(20,24,40))
px=im.load()
for li,l in enumerate(lines):
    base=li*16+16; x=4
    for c in l:
        h,w,yb,xo,rows=glyph(c)
        for r,row in enumerate(rows):
            for k,v in enumerate(row):
                X=x+xo+k; Y=base-yb+r
                if v and 0<=X<W and 0<=Y<H:
                    a=v/15; px[X,Y]=tuple(int(20*(1-a)+255*a) if i<1 else int((24 if i==1 else 40)*(1-a)+255*a) for i in range(3))
        x+=8
im=im.resize((W*3,H*3),Image.NEAREST)
im.save(sys.argv[2]); print(im.size)
