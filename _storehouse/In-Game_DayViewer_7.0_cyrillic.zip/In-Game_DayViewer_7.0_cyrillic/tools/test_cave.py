import sys,struct; sys.path.insert(0,'tools')
from mips import Emu
d=open(sys.argv[1],'rb').read()
seg=bytes(d[0x60:0x60+struct.unpack_from('<I',d,0x34+16)[0]])
def run(inp, length=None):
    e=Emu(seg); sp=0x1f000; buf=0x10000
    e.r[29]=sp; e.wr(sp+36,4,0xdead0000); e.r[17]=buf
    e.mem[buf:buf+len(inp)+1]=inp+b'\0'
    e.r[16]=len(inp.split(b'\0')[0]) if length is None else length
    e.r[31]=0x1234
    for k in (8,9,10,11,12,13,14,15,16-0): pass
    saved={k:e.r[k] for k in (16,17,18,19,20,21,22,23,29,30)}
    pc=e.run(0x1ea0,{0x1ea8})
    out=bytes(e.mem[buf:e.mem.index(0,buf)])
    assert e.r[31]==0xdead0000, hex(e.r[31])
    assert e.r[17]==saved[17] and e.r[29]==sp and all(e.r[k]==saved[k] for k in (18,19,20,21,22,23,30))
    assert e.r[2]==e.r[16]
    return out,e.r[16]
tests=[
 ('[week]\r'.encode(),),
 ('Понедельник Вторник Среда Четверг'.encode(),),
 ('Ёё ЄєІіЇїҐґ Ўў № Ю я Ж'.encode(),),
 (b'ASCII only 123 %year',),
 (b'',),
 ('Рё СЁ'.encode('cp1251'),),   # raw cp1251 passthrough (cp1251 bytes >=0xC0 untouched)
 (b'\xef\xbb\xbf# Config',),
 (b'\xd0',), (b'\xd0\x00',), (b'\xe2\x84',), (b'a\xd1',),
]
for (t,) in tests:
    out,ln=run(t)
    if t and t.decode('latin1')==t.decode('latin1'):
        try: exp=t.decode('utf-8').encode('cp1251','strict') if all(c not in t for c in []) else None
        except Exception: exp=None
    else: exp=None
    print(repr(t[:30]),'->',out.decode('cp1251',errors='replace') ,len(t),ln, 'OK' if (exp is None or out==exp) else 'EXPECTED '+repr(exp))
    assert ln==len(out) or (len(t)==0 and ln==0)
# exhaustive: every cp1251 cyrillic char via utf8
import itertools
bad=0
for c in range(0x80,0x100):
    try: u=bytes([c]).decode('cp1251')
    except: continue
    out,ln=run(('x'+u+'y').encode('utf-8'))
    if out!=('x'+u+'y').encode('cp1251'): print('MISMATCH',hex(c),u,out); bad+=1
print('exhaustive utf8->cp1251:', 'all ok' if not bad else f'{bad} bad')
# empty-line quirk: reader sets s0=1 for empty line, must stay 1
out,ln=run(b'',length=1); print('empty line len stays',ln); assert ln==1
