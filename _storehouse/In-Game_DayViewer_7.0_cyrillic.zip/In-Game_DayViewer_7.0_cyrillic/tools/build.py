#!/usr/bin/env python3
"""Patch dayviewer_game.prx: add Cyrillic (CP1251) glyphs + UTF-8->CP1251 conf converter."""
import struct, sys, math
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from PIL import Image, ImageDraw, ImageFont
from glyphs import orig_glyph, encode
from mips import Asm, bal_word

SRC, DST = sys.argv[1], sys.argv[2]
FONT = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FONT_C = '/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed.ttf'

d = bytearray(open(SRC, 'rb').read())
SEG_OFF = 0x60
(p_type, p_off, p_vaddr, p_paddr, p_filesz, p_memsz, p_flags, p_align) = struct.unpack_from('<8I', d, 0x34)
assert (p_off, p_vaddr, p_filesz, p_memsz) == (0x60, 0, 0x3a10, 0x3af8)
seg = bytearray(d[SEG_OFF:SEG_OFF + p_filesz]) + bytearray(p_memsz - p_filesz)   # materialise .bss as zeros

T_OLD, B = 0x2b1c, 0x2bdc            # old offset table / glyph blob base (vaddr)
T_NEW = p_memsz                       # new 256-entry table goes right after .bss
assert T_NEW % 4 == 0

# ------------------------------------------------------------------ glyph generation
fnt = ImageFont.truetype(FONT, 11)
fnt_c = ImageFont.truetype(FONT_C, 11)

def render(ch, font=fnt, base=14, W=26, ox=6, kern=(0.27, 0.07)):
    im = Image.new('L', (W, 28), 0)
    ImageDraw.Draw(im).text((ox, base), ch, font=font, fill=255, anchor='ls')
    px = [[im.getpixel((x, y)) / 255 for x in range(W)] for y in range(28)]
    out = [[min(1, px[y][x] + kern[0] * (px[y][x+1] if x+1 < W else 0) + kern[1] * (px[y][x-1] if x > 0 else 0))
            for x in range(W)] for y in range(28)]
    ys = [y for y in range(28) if any(v > 0.04 for v in out[y])]
    xs = [x for x in range(W) if any(out[y][x] > 0.04 for y in range(28))]
    y0, y1, x0, x1 = ys[0], ys[-1] + 1, xs[0], xs[-1] + 1
    rows = [[min(15, int(round(out[y][x] * 15))) for x in range(x0, x1)] for y in range(y0, y1)]
    w = x1 - x0
    return dict(h=y1 - y0, w=w, yb=base - y0, xo=math.floor((8 - w) / 2 + 0.5), rows=rows)

def squeeze(g, tw):
    w = g['w']; rows = []
    for r in g['rows']:
        nr = []
        for j in range(tw):
            lo, hi = j * w / tw, (j + 1) * w / tw
            acc = 0.0
            for k in range(int(lo), min(w, int(math.ceil(hi)))):
                acc += r[k] * (min(hi, k + 1) - max(lo, k))
            nr.append(min(15, int(round(acc / (hi - lo) * 1.15))))
        rows.append(nr)
    return dict(h=g['h'], w=tw, yb=g['yb'], xo=math.floor((8 - tw) / 2 + 0.5), rows=rows)

# bytes that get a glyph (cp1251) and the ASCII twin to reuse when the shapes are identical
HOMO = {0xC0:'A',0xC2:'B',0xC5:'E',0xCA:'K',0xCC:'M',0xCD:'H',0xCE:'O',0xD0:'P',0xD1:'C',0xD2:'T',0xD5:'X',
        0xB2:'I',0xE0:'a',0xF1:'c',0xE5:'e',0xEE:'o',0xF0:'p',0xF5:'x',0xF3:'y',0xB3:'i'}
CODES = list(range(0xC0, 0x100)) + [0xA8, 0xB8, 0xAA, 0xBA, 0xAF, 0xBF, 0xA5, 0xB4, 0xA1, 0xA2, 0xB9]
glyph_bytes = {}
for code in CODES:
    if code in HOMO:
        g = orig_glyph(seg, ord(HOMO[code]))
    else:
        ch = bytes([code]).decode('cp1251')
        g = render(ch)
        if g['w'] > 9:                        # keep wide letters within ~9px of the 8px cell
            g = render(ch, font=fnt_c)
        if g['w'] > 9:
            g = squeeze(g, 9)
    glyph_bytes[code] = encode(g)

# ------------------------------------------------------------------ layout of appended data
blob_start = T_NEW + 256 * 2
blob = bytearray()
offs = {}
for code in CODES:
    offs[code] = blob_start + len(blob) - B
    blob += glyph_bytes[code]
assert max(offs.values()) < 0x10000
empty_off, = struct.unpack_from('<H', seg, T_OLD)          # original ' ' glyph == empty (h=0)
table = bytearray()
for i in range(256):
    c = (i + 0x20) & 0xff
    if 0x20 <= c <= 0x7e:
        o, = struct.unpack_from('<H', seg, T_OLD + (c - 0x20) * 2)
    else:
        o = offs.get(c, empty_off)
    table += struct.pack('<H', o)

# ------------------------------------------------------------------ UTF-8 -> CP1251 line converter (code cave)
cave_start = (blob_start + len(blob) + 3) & ~3
a = Asm(cave_start)
a.move('t9', 'ra')
a.move('t0', 's1')            # src
a.move('t1', 's1')            # dst
a.label('loop')
a.lbu('t2', 0, 't0')
a.addiu('t0', 't0', 1)
a.beq('t2', 'zero', 'done'); a.nop()
a.sltiu('t3', 't2', 0x80)
a.bne('t3', 'zero', 'put'); a.nop()
a.lbu('t3', 0, 't0')          # byte after the lead byte
for lead, lab in ((0xD0, 'd0'), (0xD1, 'd1'), (0xD2, 'd2'), (0xE2, 'e2'), (0xEF, 'ef')):
    a.li('t4', lead); a.beq('t2', 't4', lab); a.nop()
a.b('put'); a.nop()

def spec(table_pairs, tag):
    for k, (second, out) in enumerate(table_pairs):
        nxt = f'{tag}_n{k}'
        a.li('t4', second); a.bne('t3', 't4', nxt); a.nop()
        a.li('t2', out); a.b('two'); a.nop()
        a.label(nxt)
    a.b('put'); a.nop()

a.label('d0')                 # U+0410..U+043F -> C0..EF
a.addiu('t4', 't3', -0x90); a.sltiu('t4', 't4', 0x30); a.beq('t4', 'zero', 'd0s'); a.nop()
a.addiu('t2', 't3', 0x30); a.b('two'); a.nop()
a.label('d0s')
spec([(0x81, 0xA8), (0x84, 0xAA), (0x86, 0xB2), (0x87, 0xAF), (0x8E, 0xA1)], 'd0s')
a.label('d1')                 # U+0440..U+044F -> F0..FF
a.addiu('t4', 't3', -0x80); a.sltiu('t4', 't4', 0x10); a.beq('t4', 'zero', 'd1s'); a.nop()
a.addiu('t2', 't3', 0x70); a.b('two'); a.nop()
a.label('d1s')
spec([(0x91, 0xB8), (0x94, 0xBA), (0x96, 0xB3), (0x97, 0xBF), (0x9E, 0xA2)], 'd1s')
a.label('d2')
spec([(0x90, 0xA5), (0x91, 0xB4)], 'd2')
a.label('e2')                 # U+2116 (numero sign) E2 84 96 -> B9
a.li('t4', 0x84); a.bne('t3', 't4', 'put'); a.nop()
a.lbu('t4', 1, 't0'); a.li('t5', 0x96); a.bne('t4', 't5', 'put'); a.nop()
a.li('t2', 0xB9); a.addiu('t0', 't0', 2); a.b('put'); a.nop()
a.label('ef')                 # UTF-8 BOM EF BB BF -> dropped
a.li('t4', 0xBB); a.bne('t3', 't4', 'put'); a.nop()
a.lbu('t4', 1, 't0'); a.li('t5', 0xBF); a.bne('t4', 't5', 'put'); a.nop()
a.addiu('t0', 't0', 2); a.b('loop'); a.nop()
a.label('two')
a.addiu('t0', 't0', 1)
a.label('put')
a.sb('t2', 0, 't1'); a.addiu('t1', 't1', 1); a.b('loop'); a.nop()
a.label('done')
a.sb('zero', 0, 't1')
a.subu('t5', 't0', 't1'); a.addiu('t5', 't5', -1); a.subu('s0', 's0', 't5')
a.lw('ra', 36, 'sp')          # the instruction displaced by the hook
a.jr('t9')
a.addu('v0', 's0', 'zero')
cave = a.finish()

new_data = bytes(table) + bytes(blob) + bytes(cave[:0])
new_data = bytes(table) + bytes(blob)
new_data += bytes(cave_start - (T_NEW + len(new_data)))
new_data += cave
new_data += bytes((-len(new_data)) % 16)

# ------------------------------------------------------------------ patch original code
def W(off): return struct.unpack_from('<I', seg, off)[0]
def P(off, w): struct.pack_into('<I', seg, off, w)

assert W(0xc00) == 0x7c091c20                 # seb v1,t1
P(0xc00, 0x312300ff)                          # andi v1,t1,0xff        (don't sign-extend / skip high chars)
assert W(0xc34) == 0x04600192                 # bltz v1,0x1280
P(0xc34, 0x00000000)                          # nop                    (delay slot 'sw t0,36(sp)' still runs)
assert W(0xc4c) == 0x24422b1c                 # addiu v0,v0,0x2b1c     (RELOC LO16 -> old table)
P(0xc4c, 0x24420000 | T_NEW)                  # point at 256-entry table (HI part stays 0, T_NEW < 0x8000)
assert T_NEW < 0x8000
assert W(0x1ea0) == 0x8fbf0024 and W(0x1ea4) == 0x02001021
P(0x1ea0, bal_word(0x1ea0, cave_start))       # bal cave   (cave does 'lw ra,36(sp)' + sets v0)

new_seg = bytes(seg) + new_data
SEG_END = SEG_OFF + len(new_seg)

# ------------------------------------------------------------------ rebuild ELF container
shoff, = struct.unpack_from('<I', d, 0x20)
shentsize, shnum, shstrndx = struct.unpack_from('<HHH', d, 0x2e)
secs = [list(struct.unpack_from('<10I', d, shoff + i * shentsize)) for i in range(shnum)]
# fields: name type flags addr off size link info align entsize
old_shstr = bytes(d[secs[shstrndx][4]:secs[shstrndx][4] + secs[shstrndx][5]])
new_name_off = len(old_shstr)
shstr = old_shstr + b'.fontext\0'
bss = secs[20]; assert d[shoff + 20*40 + 4:shoff + 20*40 + 8] == struct.pack('<I', 8)   # NOBITS
bss[1] = 1                                                    # now file-backed (zeros)
secs.append([new_name_off, 1, 3, T_NEW, SEG_OFF + p_memsz, len(new_data), 0, 0, 16, 0])   # .fontext WA

new_shoff = (SEG_END + 3) & ~3
cursor = new_shoff + len(secs) * 40
payload = bytearray()
for i, s in enumerate(secs):
    if s[1] == 0x700000a0 or i == shstrndx:
        data = shstr if i == shstrndx else bytes(d[s[4]:s[4] + s[5]])
        cursor = (cursor + 3) & ~3
        payload += bytes(cursor - new_shoff - len(secs) * 40 - len(payload))
        s[4] = cursor; s[5] = len(data)
        payload += data; cursor += len(data)

out = bytearray(d[:SEG_OFF]) + bytearray(new_seg)
out += bytes(new_shoff - len(out))
for s in secs: out += struct.pack('<10I', *s)
out += payload
struct.pack_into('<I', out, 0x20, new_shoff)
struct.pack_into('<H', out, 0x30, len(secs))
struct.pack_into('<8I', out, 0x34, p_type, p_off, p_vaddr, p_paddr, len(new_seg), len(new_seg), p_flags, p_align)
open(DST, 'wb').write(out)
print(f'wrote {DST}: {len(out)} bytes; seg filesz/memsz=0x{len(new_seg):x}; table@0x{T_NEW:x} glyphs@0x{blob_start:x} cave@0x{cave_start:x} ({len(cave)//4} insns)')
print('glyph widths:', {hex(c): struct.unpack_from('<BBbb', glyph_bytes[c])[1] for c in CODES if c not in HOMO})
