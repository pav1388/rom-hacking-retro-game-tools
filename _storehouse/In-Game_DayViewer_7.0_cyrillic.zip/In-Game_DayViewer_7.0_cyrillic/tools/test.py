import sys,struct; sys.path.insert(0,'tools')
from mips import Emu
from PIL import Image
d=open(sys.argv[1],'rb').read()
seg=bytearray(d[0x60:0x60+struct.unpack_from('<I',d,0x34+16)[0]])
# apply the loader relocation semantic: base=0 so nothing to do
orig=open('work/orig.prx','rb').read()[0x60:0x60+0x3a10]
B=0x2bdc
def lookup(c, s=seg):
    e=Emu(bytes(s))
    sp=0x1f000; e.r[29]=sp
    e.r[9]=c  # t1 = char (signed byte semantic: caller does lb -> sign-extended)
    if c>=0x80: e.r[9]=(c-256)&0xffffffff
    e.r[8]=0
    stops={0x1280,0xc90}
    pc=e.run(0xbfc,stops)
    if pc==0x1280: return None
    # at 0xc90 we've just executed 0xc8c blez (a0) ; a0=h a3=w
    return e.r[4], e.r[7]
ok=True
res={}
for c in range(256):
    r=lookup(c)
    res[c]=r
# expectations
def hdr(c):
    T=struct.unpack_from('<I',seg,0xc4c)[0]  # not used
for c in range(256):
    r=res[c]
    if 0x21<=c<=0x7e or c in range(0xc0,0x100) or c in (0xa8,0xb8,0xaa,0xba,0xaf,0xbf,0xa5,0xb4,0xa1,0xa2,0xb9):
        assert r is not None and r[0]>0, (hex(c),r)
    else:
        assert r is None or r[0]<=0, (hex(c),r)
print('lookup OK; sample', {hex(c):res[c] for c in (0x41,0xc0,0xe6,0xa8,0xff)})
# original behaviour unchanged for ASCII
so=Emu(orig)  # old code path check: compare header for ascii against new
for c in range(0x20,0x7f):
    e=Emu(bytes(orig)); e.r[29]=0x1f000; e.r[9]=c; pc=e.run(0xbfc,{0x1280,0xc90}); 
    h_old=(e.r[4],e.r[7]) if pc==0xc90 else None
    if h_old!=res[c] and not (h_old is None and res[c] is None): print('DIFF',hex(c),h_old,res[c]); ok=False
print('ascii identical' if ok else 'ascii MISMATCH')
