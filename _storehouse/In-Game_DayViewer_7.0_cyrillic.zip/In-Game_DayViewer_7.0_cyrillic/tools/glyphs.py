import struct
from PIL import Image, ImageDraw, ImageFont

def orig_glyph(seg, c, T=0x2b1c, B=0x2bdc):
    o, = struct.unpack_from('<H', seg, T + (c-0x20)*2)
    h,w,yb,xo = struct.unpack_from('<BBbb', seg, B+o)
    rb=(w+1)//2
    rows=[]
    for r in range(h):
        row=[]
        for k in range(w):
            b=seg[B+o+4+r*rb+k//2]
            row.append((b>>4) if k%2==0 else (b&15))
        rows.append(row)
    return dict(h=h,w=w,yb=yb,xo=xo,rows=rows)

def encode(g):
    h,w=g['h'],g['w']; rb=(w+1)//2
    out=bytearray(struct.pack('<BBbb',h,w,g['yb'],g['xo']))
    for r in g['rows']:
        for k in range(rb):
            a=r[2*k]; b=r[2*k+1] if 2*k+1<w else 0
            out.append((a<<4)|b)
    return bytes(out)

def render_char(font, ch, base=14, W=20, thr=0):
    im=Image.new('L',(W,24),0)
    d=ImageDraw.Draw(im)
    d.text((4,base),ch,font=font,fill=255,anchor='ls')
    bb=im.getbbox()
    if not bb: return dict(h=0,w=0,yb=0,xo=0,rows=[])
    x0,y0,x1,y1=bb
    rows=[[min(15,int(round(im.getpixel((x,y))/17))) for x in range(x0,x1)] for y in range(y0,y1)]
    w=x1-x0; h=y1-y0
    xo=int((8-w)/2+0.5)//1
    import math
    xo=math.floor((8-w)/2+0.5)
    return dict(h=h,w=w,yb=base-y0,xo=xo,rows=rows)

def show(g,label=''):
    print(label,{k:g[k] for k in('h','w','yb','xo')})
    for r in g['rows']: print('  '+''.join('.' if v==0 else '%x'%v for v in r))
