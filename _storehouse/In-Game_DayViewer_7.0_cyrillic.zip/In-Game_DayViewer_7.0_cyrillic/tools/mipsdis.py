#!/usr/bin/env python3
"""Minimal little-endian MIPS32 (Allegrex subset) disassembler + PSP PRX reloc dumper."""
import struct, sys

R = ['zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7',
     's0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra']

def sx16(v): return v - 0x10000 if v & 0x8000 else v

def dis(w, pc):
    op = w >> 26
    rs = (w >> 21) & 31; rt = (w >> 16) & 31; rd = (w >> 11) & 31
    sa = (w >> 6) & 31; fn = w & 63
    imm = w & 0xffff; simm = sx16(imm)
    tgt = ((pc + 4) & 0xf0000000) | ((w & 0x3ffffff) << 2)
    if w == 0: return 'nop'
    if op == 0:
        m = {0:'sll',2:'srl',3:'sra'}
        if fn in m: return f'{m[fn]} {R[rd]}, {R[rt]}, {sa}'
        m = {4:'sllv',6:'srlv',7:'srav'}
        if fn in m: return f'{m[fn]} {R[rd]}, {R[rt]}, {R[rs]}'
        if fn == 8: return f'jr {R[rs]}'
        if fn == 9: return f'jalr {R[rd]}, {R[rs]}'
        if fn == 10: return f'movz {R[rd]}, {R[rs]}, {R[rt]}'
        if fn == 11: return f'movn {R[rd]}, {R[rs]}, {R[rt]}'
        if fn == 12: return f'syscall'
        if fn == 16: return f'mfhi {R[rd]}'
        if fn == 18: return f'mflo {R[rd]}'
        if fn == 17: return f'mthi {R[rs]}'
        if fn == 19: return f'mtlo {R[rs]}'
        m = {24:'mult',25:'multu',26:'div',27:'divu',28:'madd',29:'maddu',46:'msub',47:'msubu'}
        if fn in m: return f'{m[fn]} {R[rs]}, {R[rt]}'
        m = {32:'add',33:'addu',34:'sub',35:'subu',36:'and',37:'or',38:'xor',39:'nor',42:'slt',43:'sltu',44:'max',45:'min'}
        if fn in m:
            if fn==37 and rt==0: return f'move {R[rd]}, {R[rs]}'
            return f'{m[fn]} {R[rd]}, {R[rs]}, {R[rt]}'
    if op == 1:
        m = {0:'bltz',1:'bgez',2:'bltzl',3:'bgezl',16:'bltzal',17:'bgezal'}
        if rt in m: return f'{m[rt]} {R[rs]}, 0x{pc+4+(simm<<2):x}'
    if op == 2: return f'j 0x{tgt:x}'
    if op == 3: return f'jal 0x{tgt:x}'
    m = {4:'beq',5:'bne',20:'beql',21:'bnel'}
    if op in m:
        if op==4 and rs==0 and rt==0: return f'b 0x{pc+4+(simm<<2):x}'
        return f'{m[op]} {R[rs]}, {R[rt]}, 0x{pc+4+(simm<<2):x}'
    m = {6:'blez',7:'bgtz',22:'blezl',23:'bgtzl'}
    if op in m: return f'{m[op]} {R[rs]}, 0x{pc+4+(simm<<2):x}'
    m = {8:'addi',9:'addiu',10:'slti',11:'sltiu'}
    if op in m: return f'{m[op]} {R[rt]}, {R[rs]}, {simm}'
    m = {12:'andi',13:'ori',14:'xori'}
    if op in m: return f'{m[op]} {R[rt]}, {R[rs]}, 0x{imm:x}'
    if op == 15: return f'lui {R[rt]}, 0x{imm:x}'
    if op == 28:
        if fn==0: return f'halt'
        if fn==36: return f'mfic {R[rt]}, {R[rd]}'
    if op == 31:
        if fn == 0x20:
            if sa==0x18: return f'seh {R[rd]}, {R[rt]}'
            if sa==0x10: return f'seb {R[rd]}, {R[rt]}'
            if sa==0x02: return f'wsbh {R[rd]}, {R[rt]}'
        if fn == 0: return f'ext {R[rt]}, {R[rs]}, {sa}, {rd+1}'
        if fn == 4: return f'ins {R[rt]}, {R[rs]}, {sa}, {rd-sa+1}'
    m = {32:'lb',33:'lh',34:'lwl',35:'lw',36:'lbu',37:'lhu',38:'lwr',40:'sb',41:'sh',42:'swl',43:'sw',46:'swr'}
    if op in m: return f'{m[op]} {R[rt]}, {simm}({R[rs]})'
    if op==47: return f'cache 0x{rt:x}, {simm}({R[rs]})'
    if op==48: return f'll {R[rt]}, {simm}({R[rs]})'
    if op==56: return f'sc {R[rt]}, {simm}({R[rs]})'
    return f'.word 0x{w:08x}'

def parse_elf(path):
    d = open(path,'rb').read()
    shoff, = struct.unpack_from('<I', d, 0x20)
    shentsize, shnum, shstrndx = struct.unpack_from('<HHH', d, 0x2e)
    secs = []
    for i in range(shnum):
        nm, ty, fl, ad, of, sz, lk, inf, al, es = struct.unpack_from('<10I', d, shoff + i*shentsize)
        secs.append(dict(name_off=nm, type=ty, flags=fl, addr=ad, off=of, size=sz, link=lk, info=inf, align=al, entsize=es))
    so = secs[shstrndx]['off']
    for s in secs:
        e = d.index(b'\0', so + s['name_off'])
        s['name'] = d[so + s['name_off']:e].decode()
    return d, secs

def relocs(d, secs):
    out = []
    for s in secs:
        if s['type'] == 0x700000a0:
            for i in range(s['size']//8):
                ro, ri = struct.unpack_from('<II', d, s['off'] + i*8)
                out.append(dict(sect=s['name'], off=ro, type=ri & 0xff, ofs_seg=(ri>>8)&0xff, addr_seg=(ri>>16)&0xff))
    return out

if __name__ == '__main__':
    path = sys.argv[1]
    a = int(sys.argv[2], 0); b = int(sys.argv[3], 0)
    d, secs = parse_elf(path)
    rel = {}
    for r in relocs(d, secs):
        if r['sect'] == '.rel.text': rel[r['off']] = r
    names = {1:'16',2:'32',4:'J26',5:'HI16',6:'LO16',7:'GPREL16'}
    seg = d[0x60:]
    for pc in range(a, b, 4):
        w, = struct.unpack_from('<I', seg, pc)
        r = rel.get(pc)
        print(f'{pc:05x}: {w:08x}  {dis(w, pc):40s}' + (f' ; RELOC {names.get(r["type"],r["type"])} seg{r["ofs_seg"]}->{r["addr_seg"]}' if r else ''))
