# In-Game DayViewer 7.0 — патч кириллицы (CP1251 / UTF-8)

Дата работы: 2026-11-16. Плагин: `dayviewer_game.prx` (PSP kernel PRX, MIPS Allegrex, 2012).

## Структура архива
- `original/` — исходные файлы (prx, conf, game.txt, описание релиза)
- `patched/` — результат: `dayviewer_game.prx` и `dayviewer_game_conf.txt` (CP1251, русские дни/месяцы)
- `docs/preview.png` — превью шрифта, отрисованного из патченного .prx; `original_text_disassembly.txt` — дизассемблер .text оригинала
- `tools/` — скрипты (Python 3 + Pillow, без внешних зависимостей)

## Устройство PRX
- ELF32 LE, тип 0xFFA0 (PRX), один LOAD-сегмент (file off 0x60 = vaddr 0). Релокации в секциях типа 0x700000A0 (.rel.*); 457 записей.
- Импорты: LoadCore, IoFileMgr, Utils, ThreadMan, Sysclib, SysMem, SysTimer, Init, sceRtc, scePower, sceCtrl_driver. Плагин патчит модуль sceImpose_Driver (в .data — таблица смещений для разных прошивок).
- Функция отрисовки глифа: **0xBFC** (аргументы a0=x, a1=y, a2/a3=цвета, t0=флаги, t1=символ). Кадр 16 бит, stride 512 px, альфа-смешивание по 4-битной маске.
- Шрифт (`.data`): таблица u16-смещений по индексу `(c-0x20)&0xFF` на vaddr 0x2B1C (95 записей) + блоб глифов на 0x2BDC.
  Глиф = заголовок 4 байта `{h, w, yb, xo}` (высота, ширина, высота над базовой линией, сдвиг X; знаковые yb/xo) + h строк по ceil(w/2) байт, 2 пикселя (4 бита альфы) на байт, старший ниббл — левый пиксель.
- Шаг символа фиксирован: 8 px (+ `\` — перевод строки). Строка обрабатывается побайтно.
- Оригинал: `seb v1,t1; bltz v1,end` отбрасывал символы ≥0x80 → кириллица не рисовалась.

## Патч (изменены ровно 4 слова .text, новых релокаций нет)
| адрес | было | стало |
|---|---|---|
| 0xC00 | `seb v1,t1` | `andi v1,t1,0xff` |
| 0xC34 | `bltz v1,0x1280` | `nop` (delay slot `sw t0,36(sp)` остаётся) |
| 0xC4C | `addiu v0,v0,0x2B1C` (RELOC LO16) | `addiu v0,v0,0x3AF8` — новая таблица на 256 записей |
| 0x1EA0 | `lw ra,36(sp)` (эпилог читалки строк конфига 0x1E48) | `bal cave` |

Хвост сегмента (vaddr 0x3AF8…; .bss материализован нулями, filesz=memsz=0x4A58, добавлена секция `.fontext`):
1. новая таблица смещений (256×u16; смещения считаются от прежней базы 0x2BDC, помещаются в u16);
2. 59 новых глифов CP1251: А–я (0xC0–0xFF), Ё/ё, Є є І і Ї ї Ґ ґ Ў ў, № — идентичные латинице (А В Е К М Н О Р С Т Х І а с е о р х у і) берутся из оригинала, остальные рисуются DejaVu Sans 11px (hinted) + горизонтальное «размазывание» для имитации жирности; ширина >9 сжимается;
3. «cave» (153 инструкции): конвертер UTF-8→CP1251 на месте для каждой прочитанной строки конфига; корректирует длину (s0) и v0, пропускает BOM, неизвестные последовательности оставляет как есть.

## Проверка (без реального железа)
- `tools/test.py` — мини-эмулятор MIPS гонит пролог функции 0xBFC для всех 256 кодов: ASCII идентичен оригиналу, кириллица находит непустой глиф.
- `tools/test_cave.py` — прогон конвертера через хук для всех букв CP1251, BOM, обрывов, пустой строки. Известный нюанс: сырой CP1251 «Рё»/«Сё» (байты D0/D1 + B8) трактуется как UTF-8.
- На PSP **не запускалось** — первый запуск в игре нужно проверить вручную.

## Воспроизведение
```
python3 -I tools/build.py original/dayviewer_game.prx out.prx
python3 -I tools/test.py out.prx && python3 -I tools/test_cave.py out.prx
python3 -I tools/preview.py out.prx preview.png
```
(`test.py` ожидает `work/orig.prx` рядом — положите оригинал как `work/orig.prx`; путь к DejaVu Sans в `build.py` — `/usr/share/fonts/truetype/dejavu/`.)
Инструменты: `mipsdis.py` (дизассемблер + парсер ELF/реллок: `python3 mipsdis.py f.prx 0x0 0x100`), `mips.py` (ассемблер + эмулятор подмножества MIPS), `glyphs.py` (декод/кодирование глифов).

## Установка
`seplugins/dayviewer_game.prx` + `seplugins/dayviewer_game_conf.txt`; в `game.txt`: `ms0:/seplugins/dayviewer_game.prx 1`. Конфиг — ANSI (CP1251) или UTF-8.
